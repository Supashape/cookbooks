#
# Cookbook:: solo
# Recipe:: default
#
# Copyright:: 2021, The Authors, All Rights Reserved.
file 'hello.txt' do
  content 'Welcome to Chef'
end

include_recipe "notepadpp::default"
include_recipe "git::default"
include_recipe "nodejs::default"
#include_recipe "vscode::default"
