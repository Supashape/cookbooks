# Policyfile.rb - Describe how you want Chef Infra Client to build your system.
#
# For more information on the Policyfile feature, visit
# https://docs.chef.io/policyfile.html

# A name that describes what the system you're building with Chef does.
name 'solo'

# Where to find external cookbooks:
default_source :supermarket

# run_list: chef-client will run these recipes in the order specified.
run_list 'solo::default' #, 'notepadpp::default'

# Specify a custom source for a single cookbook:
cookbook 'solo', path: '.'
#cookbook 'notepadpp', path: '../notepadpp'
#cookbook 'windows', path: '../windows'
#cookbook 'git', path: '../git'
#cookbook 'nodejs', path: '../nodejs'
#cookbook 'ark', path: '../ark'
#cookbook 'chocolatey', path: '../chocolatey'
#cookbook 'seven_zip', path: '../seven_zip'
#cookbook 'vscode', path: '../vscode'
#cookbook 'nodejs', path: 'C:/Vagrant/cookbooks/nodejs' Pfadangabe funktioniert so nicht, springt immernoch in Solo > cookbooks default

